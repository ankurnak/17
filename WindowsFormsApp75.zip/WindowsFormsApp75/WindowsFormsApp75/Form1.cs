﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp75
{
    public partial class Form1 : Form
    {
 

        public Form1()
        {
            InitializeComponent();
        }

        private async Task button1_ClickAsync(object sender, EventArgs e)
        {
            string inputFile = textBox1.Text;
            string outputFile = textBox2.Text;

            await Task.Run(() =>
            {
                try
                {
                    byte[] key = GenerateRandomKey(16); // Генеруємо випадковий ключ довжиною 16 байт

                    using (FileStream inputStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read))
                    {
                        using (FileStream outputStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write))
                        {
                            IDEAEngine engine = new IDEAEngine();
                            BufferedBlockCipher cipher = new BufferedBlockCipher(engine);
                            KeyParameter keyParam = new KeyParameter(key);

                            cipher.Init(true, keyParam); // Ініціалізуємо шифр з ключем

                            byte[] inputBuffer = new byte[cipher.GetBlockSize()];
                            byte[] outputBuffer = new byte[cipher.GetOutputSize(inputBuffer.Length)];

                            int inputLength = 0;
                            int outputLength = 0;

                            while ((inputLength = inputStream.Read(inputBuffer, 0, inputBuffer.Length)) > 0)
                            {
                                outputLength = cipher.ProcessBytes(inputBuffer, 0, inputLength, outputBuffer, 0);
                                outputStream.Write(outputBuffer, 0, outputLength);
                            }

                            outputLength = cipher.DoFinal(outputBuffer, 0);
                            outputStream.Write(outputBuffer, 0, outputLength);
                        }
                    }

                    MessageBox.Show("Шифрування IDEA завершено успішно!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Сталася помилка під час шифрування: " + ex.Message);
                }
            });
        }

        private byte[] GenerateRandomKey(int v)
        {
            throw new NotImplementedException();
        }

        private async Task button2_ClickAsync(object sender, EventArgs e)
        {
            string inputFile = textBox1.Text;
            string outputFile = textBox2.Text;
            await Task.Run(() =>
            {
                try
                {
                    byte[] key = GenerateRandomKey(16); // Генеруємо випадковий ключ довжиною 16 байт

                    using (FileStream inputStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read))
                    {
                        using (FileStream outputStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write))
                        {
                            Mdc4Digest digest = new Mdc4Digest();
                            BufferedBlockCipher cipher = new BufferedBlockCipher(new CfbBlockCipher(new AesEngine(), 128));
                            KeyParameter keyParam = new KeyParameter(key);

                           

                            byte[] inputBuffer = new byte[cipher.GetBlockSize()];
                            byte[] outputBuffer = new byte[cipher.GetOutputSize(inputBuffer.Length)];

                            int inputLength = 0;
                            int outputLength = 0;

                            while ((inputLength = inputStream.Read(inputBuffer, 0, inputBuffer.Length)) > 0)
                            {
                                digest.BlockUpdate(inputBuffer, 0, inputLength); // Обчислюємо хеш від вхідного буфера
                                outputLength = cipher.ProcessBytes(inputBuffer, 0, inputLength, outputBuffer, 0);
                                outputStream.Write(outputBuffer, 0, outputLength);
                            }

                            outputLength = cipher.DoFinal(outputBuffer, 0);
                            outputStream.Write(outputBuffer, 0, outputLength);

                            byte[] hash = new byte[digest.GetDigestSize()];
                            digest.DoFinal(hash, 0); // Отримуємо фінальний хеш

                            // Зберігаємо хеш у файл з тим же ім'ям, що й вихідний файл, але з розширенням ".mdc4"
                            string hashFile = Path.ChangeExtension(outputFile, "mdc4");
                            File.WriteAllBytes(hashFile, hash);
                        }
                    }

                    MessageBox.Show("Шифрування MDC-4 завершено успішно!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Сталася помилка під час шифрування: " + ex.Message);
                }
            });
        }

        private async Task button3_ClickAsync(object sender, EventArgs e)
        {
            string inputFile = textBox1.Text;
            string outputFile = textBox2.Text;

            await Task.Run(() =>
            {
                try
                {
                    byte[] key = GenerateRandomKey(8); // Генеруємо випадковий ключ довжиною 8 байт

                    using (FileStream inputStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read))
                    {
                        using (FileStream outputStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write))
                        {
                            A5Stream cipher = new A5Stream();
                            KeyParameter keyParam = new KeyParameter(key);

                            cipher.Init(true, keyParam); // Ініціалізуємо шифр з ключем

                            byte[] inputBuffer = new byte[1024];
                            byte[] outputBuffer = new byte[inputBuffer.Length];

                            int inputLength = 0;
                            int outputLength = 0;

                            while ((inputLength = inputStream.Read(inputBuffer, 0, inputBuffer.Length)) > 0)
                            {
                                outputLength = cipher.ProcessBytes(inputBuffer, 0, inputLength, outputBuffer, 0);
                                outputStream.Write(outputBuffer, 0, outputLength);
                            }

                            byte[] remainder = cipher.Remainder; // Отримуємо будь-які байти, що залишилися в шифрі

                            if (remainder != null && remainder.Length > 0)
                            {
                                outputLength = cipher.ProcessBytes(remainder, 0, remainder.Length, outputBuffer, 0);
                                outputStream.Write(outputBuffer, 0, outputLength);
                            }
                        }
                    }

                    MessageBox.Show("Шифрування потоковим шифром A5 завершено успішно!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Сталася помилка під час шифрування: " + ex.Message);
                }
            });
        }
    }

    

    class IDEAEngine
    {
        public IDEAEngine()
        {
        }
    }

    class BufferedBlockCipher
    {
        private IDEAEngine engine;

        public BufferedBlockCipher(IDEAEngine engine)
        {
            this.engine = engine;
        }

        internal int DoFinal(byte[] outputBuffer, int v)
        {
            throw new NotImplementedException();
        }

        internal int GetBlockSize()
        {
            throw new NotImplementedException();
        }

        internal int GetOutputSize(int length)
        {
            throw new NotImplementedException();
        }

        internal void Init(bool v, KeyParameter keyParam)
        {
            throw new NotImplementedException();
        }

        internal int ProcessBytes(byte[] inputBuffer, int v1, int inputLength, byte[] outputBuffer, int v2)
        {
            throw new NotImplementedException();
        }
    }

    class KeyParameter
    {
        private byte[] key;

        public KeyParameter(byte[] key)
        {
            this.key = key;
        }
    }

    

    class Mdc4Digest
    {
        public Mdc4Digest()
        {
        }

        internal void BlockUpdate(byte[] inputBuffer, int v, int inputLength)
        {
            throw new NotImplementedException();
        }

        internal void DoFinal(byte[] hash, int v)
        {
            throw new NotImplementedException();
        }

        internal int GetDigestSize()
        {
            throw new NotImplementedException();
        }
    }

    class A5Stream
    {
        public A5Stream()
        {
        }

        public byte[] Remainder { get; internal set; }

        internal void Init(bool v, KeyParameter keyParam)
        {
            throw new NotImplementedException();
        }

        internal int ProcessBytes(byte[] remainder, int v1, int length, byte[] outputBuffer, int v2)
        {
            throw new NotImplementedException();
        }
    }

    class CfbBlockCipher : IDEAEngine
    {
        private AesEngine aesEngine;
        private int v;

        public CfbBlockCipher(AesEngine aesEngine, int v)
        {
            this.aesEngine = aesEngine;
            this.v = v;
        }
    }

    class AesEngine
    {
        public AesEngine()
        {
        }
    }

    
        
    }

